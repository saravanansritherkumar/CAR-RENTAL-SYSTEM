﻿using CarRentalSystem.dao;
using CarRentalSystem.dao.implementation;
using CarRentalSystem.entity;
using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CarRentalSystem.main
{
    class MainModule
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=10.4.132.9;Database=CarRent_7383;TrustServerCertificate=True;Trusted_Connection=True;";
            ICarLeaseRepository car = new CarLeaseRepository(connectionString);
            while (true)
            {
                Console.WriteLine("Choose an option:");
                Console.WriteLine("1. Add Car");
                Console.WriteLine("2. Remove Car");
                Console.WriteLine("3. List Available Cars");
                Console.WriteLine("4. List Rented Cars");
                Console.WriteLine("5. Find Car By ID");
                Console.WriteLine("6. Add Customer");
                Console.WriteLine("7. Remove Customer");
                Console.WriteLine("8. List Customers");
                Console.WriteLine("9. Find Customer By ID");
                Console.WriteLine("10. Create Lease");
                Console.WriteLine("11. Return Car");
                Console.WriteLine("12. Record Payment");
                Console.WriteLine("13. Exit");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Car Details (Make, Model, Year, DailyRate, Status, PassengerCapacity, EngineCapacity):");
                        string make = Console.ReadLine();
                        string model = Console.ReadLine();
                        int year = Convert.ToInt32(Console.ReadLine());
                        double dailyRate = double.Parse(Console.ReadLine());
                        string status = Console.ReadLine();
                        int passengerCapacity = int.Parse(Console.ReadLine());
                        int engineCapacity = int.Parse(Console.ReadLine());
                        Console.WriteLine(car.AddCar(new Vehicle { Make = make, Model = model, Year = year, DailyRate = (int)dailyRate, Status = status, PassengerCapacity = passengerCapacity, EngineCapacity = engineCapacity }));
                        break;
                    case 2:
                        Console.WriteLine("Enter Car ID to Remove:");
                        int carId = int.Parse(Console.ReadLine());
                        car.RemoveCar(carId);
                        break;
                    case 3:
                        var availableCars = car.ListAvailableCars();
                        foreach (var vehicle in availableCars)
                        {
                            Console.WriteLine($"{vehicle.VehicleID} - {vehicle.Make} {vehicle.Model} ({vehicle.Year})");
                        }
                        break;
                    case 4:
                        var rentedCars = car.ListRentedCars();
                        foreach (var vehicle in rentedCars)
                        {
                            Console.WriteLine($"{vehicle.VehicleID} - {vehicle.Make} {vehicle.Model} ({vehicle.Year})");
                        }
                        break;
                    case 5:
                        Console.WriteLine("Enter Car ID to Find:");
                        carId = int.Parse(Console.ReadLine());
                        var foundCar = car.FindCarById(carId);
                        foreach (var vehicle in foundCar)
                        {
                            Console.WriteLine($"{vehicle.VehicleID} - {vehicle.Make} {vehicle.Model} ({vehicle.Year})");
                        }
                        break;
                    case 6:
                        Console.WriteLine("Enter Customer Details (FirstName, LastName, Email, PhoneNumber):");
                        string firstName = Console.ReadLine();
                        string lastName = Console.ReadLine();
                        string email = Console.ReadLine();
                        string phoneNumber = Console.ReadLine();
                        car.AddCustomer(new Customer { FirstName = firstName, LastName = lastName, Email = email, PhoneNumber = phoneNumber });
                        break;
                    case 7:
                        Console.WriteLine("Enter Customer ID to Remove:");
                        int customerId = int.Parse(Console.ReadLine());
                        car.RemoveCustomer(customerId);
                        break;
                    case 8:
                        var customers = car.ListCustomers();
                        foreach (var customer in customers)
                        {
                            Console.WriteLine($"{customer.CustomerID} - {customer.FirstName} {customer.LastName} ({customer.Email})");
                        }
                        break;
                    case 9:
                        Console.WriteLine("Enter Customer ID to Find:");
                        customerId = int.Parse(Console.ReadLine());
                        var foundCustomer = car.FindCustomerById(customerId);
                        foreach (var customer in foundCustomer)
                        {
                            Console.WriteLine($"{customer.CustomerID} - {customer.FirstName} {customer.LastName} ({customer.Email})");
                        }
                        break;
                    case 10:
                        Console.WriteLine("Enter Lease Details (Customer ID, Car ID, Start Date, End Date, Type):");
                        customerId = int.Parse(Console.ReadLine());
                        carId = int.Parse(Console.ReadLine());
                        string startDate = Console.ReadLine();
                        string endDate = Console.ReadLine();
                        string type = Console.ReadLine();
                        car.CreateLease(customerId, carId, startDate, endDate, type);
                        break;
                    case 11:
                        Console.WriteLine("Enter Lease ID to Return Car:");
                        int leaseId = int.Parse(Console.ReadLine());
                        endDate = Console.ReadLine();
                        car.ReturnCar(leaseId, endDate);
                        break;
                    case 12:
                        var activeLeases = car.ListActiveLeases();
                        foreach (var lease in activeLeases)
                        {
                            Console.WriteLine($"{lease.LeaseID} - Car ID: {lease.VehicleID}, Customer ID: {lease.CustomerID}, Start Date: {lease.StartDate}, End Date: {lease.EndDate}, Type: {lease.Type}");
                        }
                        break;

                    case 13:
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

            }

            car.AddCar(new Vehicle
            {
                Make = "India",
                Model = "Heavy",
                Year = 2025,
                DailyRate = 100,
                Status = "Avaliable",
                PassengerCapacity = 5,
                EngineCapacity = 200
            });
        }
    }
}
