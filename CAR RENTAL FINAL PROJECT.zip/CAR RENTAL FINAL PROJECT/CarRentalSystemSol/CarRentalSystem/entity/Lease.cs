﻿using System.Globalization;

namespace CarRentalSystem.entity
{
    public class Lease
    {
        public int LeaseID { get; set; }
        public int VehicleID { get; set; }
        public int CustomerID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Type { get; set; }
        public string status { get; set; }  
    }
}
