﻿using CarRentalSystem.entity;
using System.Collections.Generic;

namespace CarRentalSystem.dao
{
    public interface ICarLeaseRepository
    {
        // Car Management
        bool AddCar(Vehicle car);
        bool RemoveCar(int carID);
        List<Vehicle> ListAvailableCars();
        List<Vehicle> ListRentedCars();
        List<Vehicle> FindCarById(int carID);

        // Customer Management
        bool AddCustomer(Customer customer);
        bool RemoveCustomer(int customerID);
        List<Customer> ListCustomers();
        List<Customer> FindCustomerById(int customerID);

        // Lease Management
        bool CreateLease(int customerID, int carID, string startDate, string endDate,string type);
        bool ReturnCar(int leaseID,string endDate);
        List<Lease> ListActiveLeases();
        List<Lease> ListLeaseHistory();

        // Payment Handling
        bool RecordPayment(int leaseID, double amount,string date);
    }
}
