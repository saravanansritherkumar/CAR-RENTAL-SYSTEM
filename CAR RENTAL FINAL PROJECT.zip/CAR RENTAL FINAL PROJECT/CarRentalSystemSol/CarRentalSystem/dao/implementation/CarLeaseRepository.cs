﻿using CarRentalSystem.entity;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;

namespace CarRentalSystem.dao.implementation
{
    internal class CarLeaseRepository : ICarLeaseRepository
    {
        private readonly string _connectionString;

        public CarLeaseRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        // Add a new car to the database
        public bool AddCar(Vehicle car)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO Vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) VALUES (@make, @model, @year, @dailyRate, @status, @passengerCapacity, @engineCapacity);", connection))
                {
                    command.Parameters.AddWithValue("@make", car.Make);
                    command.Parameters.AddWithValue("@model", car.Model);
                    command.Parameters.AddWithValue("@year", car.Year);
                    command.Parameters.AddWithValue("@dailyRate", car.DailyRate);
                    command.Parameters.AddWithValue("@status", car.Status);
                    command.Parameters.AddWithValue("@passengerCapacity", car.PassengerCapacity);
                    command.Parameters.AddWithValue("@engineCapacity", car.EngineCapacity);

                    int row=command.ExecuteNonQuery();
                    if (row > 0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }

        // Remove a car from the database
        public bool RemoveCar(int carID)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DELETE FROM Vehicle WHERE vehicleID = @carID;", connection))
                {
                    command.Parameters.AddWithValue("@carID", carID);
                    int row=command.ExecuteNonQuery();
                    if (row>0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }


        // List all available cars
        public List<Vehicle> ListAvailableCars()
        {
            var vehicles = new List<Vehicle>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT vehicleID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity FROM Vehicle WHERE status = 'Available';", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            vehicles.Add(new Vehicle
                            {
                                VehicleID = (int)reader["vehicleID"],
                                Make = (string)reader["make"],
                                Model = (string)reader["model"],
                                Year = (int)reader["year"],
                                DailyRate = (int)reader["dailyRate"],
                                Status = (string)reader["status"],
                                PassengerCapacity = (int)reader["passengerCapacity"],
                                EngineCapacity = (int)reader["engineCapacity"]
                            });
                        }
                    }
                }
            }
            return vehicles;
        }

        // List all rented cars
        public List<Vehicle> ListRentedCars()
        {
            var vehicles = new List<Vehicle>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT Vehicle.vehicleID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity FROM Vehicle JOIN Lease ON Vehicle.vehicleID = Lease.vehicleID WHERE Vehicle.status = 'Available';", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            vehicles.Add(new Vehicle
                            {
                                VehicleID = (int)reader["vehicleID"],
                                Make = (string)reader["make"],
                                Model = (string)reader["model"],
                                Year = (int)reader["year"],
                                DailyRate = (int)reader["dailyRate"],
                                Status = (string)reader["status"],
                                PassengerCapacity = (int)reader["passengerCapacity"],
                                EngineCapacity = (int)reader["engineCapacity"]
                            });
                        }
                    }
                }
            }
            return vehicles;
        }

        // Find a car by its ID
        public List<Vehicle> FindCarById(int carID)
        {
            var vehicles = new List<Vehicle>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT vehicleID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity FROM Vehicle WHERE vehicleID = @carID;", connection))
                {
                    command.Parameters.AddWithValue("@carID", carID);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            vehicles.Add(new Vehicle
                            {
                                VehicleID = (int)reader["vehicleID"],
                                Make = (string)reader["make"],
                                Model = (string)reader["model"],
                                Year = (int)reader["year"],
                                DailyRate = (int)reader["dailyRate"],
                                Status = (string)reader["status"],
                                PassengerCapacity = (int)reader["passengerCapacity"],
                                EngineCapacity = (int)reader["engineCapacity"]
                            });
                        }
                    }
                }
            }
            return vehicles;
        }

        // Add a new customer to the database
        public bool AddCustomer(Customer customer)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO Customer (firstName, lastName, email, phoneNumber) VALUES (@firstName, @lastName, @Email, @PhoneNumber);", connection))
                {
                    command.Parameters.AddWithValue("@firstName", customer.FirstName);
                    command.Parameters.AddWithValue("@lastName", customer.LastName);
                    command.Parameters.AddWithValue("@Email", customer.Email);
                    command.Parameters.AddWithValue("@PhoneNumber", customer.PhoneNumber);

                    int row=command.ExecuteNonQuery();
                    if (row > 0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }

        // Remove a customer from the database
        public bool RemoveCustomer(int customerID)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DELETE FROM Customer WHERE customerID = @customerID;", connection))
                {
                    command.Parameters.AddWithValue("@customerID", customerID);
                    int row=command.ExecuteNonQuery();
                    if(row > 0)
                    {
                        status=true;
                    }
                }
            }
            return status;
        }

        // List all customers
        public List<Customer> ListCustomers()
        {
            var customers = new List<Customer>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT customerID, firstName, lastName, email, phoneNumber FROM Customer;", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            customers.Add(new Customer
                            {
                                CustomerID = (int)reader["customerID"],
                                FirstName = (string)reader["firstName"],
                                LastName = (string)reader["lastName"],
                                Email = (string)reader["email"],
                                PhoneNumber = (string)reader["phoneNumber"]
                            });
                        }
                    }
                }
            }
            return customers;
        }
        public bool RecordPayment(int leaseID, double amount, string date)
        {
            bool status= false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO Payment (leaseID,paymentDate,amount)" +
                    " VALUES(@leaseID,@date,@amount);", connection))
                {
                    command.Parameters.AddWithValue("@leaseID", leaseID);
                    command.Parameters.AddWithValue("@date", date);
                    command.Parameters.AddWithValue("@amount", amount);
                    int row=command.ExecuteNonQuery();
                    if (row > 0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }

        // Find a customer by their ID
        public List<Customer> FindCustomerById(int customerID)
        {
            var customers = new List<Customer>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT customerID, firstName, lastName, email, phoneNumber FROM Customer WHERE customerID = @customerID;", connection))
                {
                    command.Parameters.AddWithValue("@customerID", customerID);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            customers.Add(new Customer
                            {
                                CustomerID = (int)reader["customerID"],
                                FirstName = (string)reader["firstName"],
                                LastName = (string)reader["lastName"],
                                Email = (string)reader["email"],
                                PhoneNumber = (string)reader["phoneNumber"]
                            });
                        }
                    }
                }
            }
            return customers;
        }

        // Create a new lease
        public bool CreateLease(int customerID, int carID, string startDate, string endDate, string type)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO Lease (vehicleID, customerID, startDate, endDate, type) VALUES (@vehicleID, @customerID, @startDate, @endDate, @type);", connection))
                {
                    command.Parameters.AddWithValue("@vehicleID", carID);
                    command.Parameters.AddWithValue("@customerID", customerID);
                    command.Parameters.AddWithValue("@startDate", startDate);
                    command.Parameters.AddWithValue("@endDate", endDate);
                    command.Parameters.AddWithValue("@type", type);
                    int row = command.ExecuteNonQuery();
                    if (row > 0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }

        // Return a car (end a lease)
        public bool ReturnCar(int leaseID, string endDate)
        {
            bool status = false;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("UPDATE Lease SET endDate = @endDate WHERE leaseID = @leaseID;", connection))
                {
                    command.Parameters.AddWithValue("@endDate", endDate);
                    command.Parameters.AddWithValue("@leaseID", leaseID);
                    int row = command.ExecuteNonQuery();
                    if (row > 0)
                    {
                        status = true;
                    }
                }
            }
            return status;
        }
        public List<Lease> ListLeaseHistory()
        {
            var leases = new List<Lease>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT leaseID, vehicleID, customerID, startDate, endDate, type FROM Lease;", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            leases.Add(new Lease
                            {
                                LeaseID = (int)reader["leaseID"],
                                VehicleID = (int)reader["vehicleID"],
                                CustomerID = (int)reader["customerID"],
                                StartDate = (string)reader["startDate"],
                                EndDate = (string)reader["endDate"],
                                Type = (string)reader["type"]
                            });
                        }
                    }
                }
            }
            return leases;
        }
        public List<Lease> ListActiveLeases()
        {
            var leases = new List<Lease>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT leaseID, vehicleID, customerID, startDate, endDate, type FROM Lease WHERE endDate IS NULL;", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            leases.Add(new Lease
                            {
                                LeaseID = (int)reader["leaseID"],
                                VehicleID = (int)reader["vehicleID"],
                                CustomerID = (int)reader["customerID"],
                                StartDate = (string)reader["startDate"],
                                EndDate = (string)reader["endDate"],
                                Type = (string)reader["type"]
                            });
                        }
                    }
                }
            }
            return leases;    
        }


    }
}


 